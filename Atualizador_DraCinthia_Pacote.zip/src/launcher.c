typedef unsigned short WCHAR;
typedef unsigned short WORD;
typedef unsigned int DWORD;
typedef int BOOL;
typedef void *HANDLE;
typedef void *LPVOID;

typedef struct {
    DWORD cb;
    WCHAR *lpReserved;
    WCHAR *lpDesktop;
    WCHAR *lpTitle;
    DWORD dwX;
    DWORD dwY;
    DWORD dwXSize;
    DWORD dwYSize;
    DWORD dwXCountChars;
    DWORD dwYCountChars;
    DWORD dwFillAttribute;
    DWORD dwFlags;
    WORD wShowWindow;
    WORD cbReserved2;
    unsigned char *lpReserved2;
    HANDLE hStdInput;
    HANDLE hStdOutput;
    HANDLE hStdError;
} STARTUPINFOW;

typedef struct {
    HANDLE hProcess;
    HANDLE hThread;
    DWORD dwProcessId;
    DWORD dwThreadId;
} PROCESS_INFORMATION;

extern __attribute__((ms_abi)) BOOL CreateProcessW(
    const WCHAR *, WCHAR *, LPVOID, LPVOID, BOOL, DWORD, LPVOID,
    const WCHAR *, STARTUPINFOW *, PROCESS_INFORMATION *
);
extern __attribute__((ms_abi)) DWORD WaitForSingleObject(HANDLE, DWORD);
extern __attribute__((ms_abi)) BOOL CloseHandle(HANDLE);
extern __attribute__((ms_abi)) BOOL GetExitCodeProcess(HANDLE, DWORD *);
extern __attribute__((ms_abi, noreturn)) void ExitProcess(DWORD);
extern __attribute__((ms_abi)) int MessageBoxW(HANDLE, const WCHAR *, const WCHAR *, unsigned int);

#include "launcher-command.inc"

static WCHAR errorText[] = {
    'N','a','o',' ','f','o','i',' ','p','o','s','s','i','v','e','l',' ',
    'i','n','i','c','i','a','r',' ','o',' ','a','t','u','a','l','i','z','a','d','o','r','.',0
};

static WCHAR errorTitle[] = {
    'D','r','a','.',' ','C','i','n','t','h','i','a',' ','L','e','o','n','e',0
};

static void zero_memory(void *target, unsigned int size) {
    unsigned char *bytes = (unsigned char *)target;
    unsigned int index;

    for (index = 0; index < size; index++) {
        bytes[index] = 0;
    }
}

__attribute__((ms_abi, noreturn)) void _start(void) {
    STARTUPINFOW startupInfo;
    PROCESS_INFORMATION processInfo;
    DWORD exitCode = 1;
    BOOL created;

    zero_memory(&startupInfo, (unsigned int)sizeof(startupInfo));
    zero_memory(&processInfo, (unsigned int)sizeof(processInfo));
    startupInfo.cb = (DWORD)sizeof(startupInfo);

    created = CreateProcessW(
        (const WCHAR *)0,
        commandLine,
        (LPVOID)0,
        (LPVOID)0,
        0,
        0x08000000u,
        (LPVOID)0,
        (const WCHAR *)0,
        &startupInfo,
        &processInfo
    );

    if (!created) {
        MessageBoxW((HANDLE)0, errorText, errorTitle, 0x00000010u);
        ExitProcess(1);
    }

    CloseHandle(processInfo.hThread);
    WaitForSingleObject(processInfo.hProcess, 0xFFFFFFFFu);
    GetExitCodeProcess(processInfo.hProcess, &exitCode);
    CloseHandle(processInfo.hProcess);

    if (exitCode != 0) {
        MessageBoxW((HANDLE)0, errorText, errorTitle, 0x00000010u);
    }

    ExitProcess(exitCode);
}

