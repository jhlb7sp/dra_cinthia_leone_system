Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

[System.Windows.Forms.Application]::EnableVisualStyles()

$ProjectPath = 'C:\PRJ-CONSULTORIO'
$BranchName = 'main'
$RemoteName = 'origin'
$script:Running = $false

$logDirectory = Join-Path $env:LOCALAPPDATA 'DraCinthia'
$logFile = Join-Path $logDirectory 'atualizador.log'

if (-not (Test-Path $logDirectory)) {
    New-Item -ItemType Directory -Path $logDirectory -Force | Out-Null
}

function Write-UpdateLog {
    param([string]$Message)

    $line = '[{0}] {1}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Message
    Add-Content -Path $logFile -Value $line -Encoding UTF8
}

function Invoke-Program {
    param(
        [Parameter(Mandatory = $true)][string]$FilePath,
        [Parameter(Mandatory = $true)][string[]]$Arguments
    )

    $output = & $FilePath @Arguments 2>&1 | Out-String
    $exitCode = $LASTEXITCODE
    $output = $output.Trim()

    if ($output) {
        Write-UpdateLog $output
    }

    if ($exitCode -ne 0) {
        if (-not $output) {
            $output = "O comando terminou com o código $exitCode."
        }

        throw $output
    }

    return $output
}

$form = New-Object System.Windows.Forms.Form
$form.Text = 'Atualizador - Dra. Cinthia Leone'
$form.ClientSize = New-Object System.Drawing.Size(540, 285)
$form.StartPosition = 'CenterScreen'
$form.FormBorderStyle = 'FixedDialog'
$form.MaximizeBox = $false
$form.MinimizeBox = $true
$form.BackColor = [System.Drawing.ColorTranslator]::FromHtml('#FAF3E7')
$form.Font = New-Object System.Drawing.Font('Segoe UI', 9)

$header = New-Object System.Windows.Forms.Panel
$header.Location = New-Object System.Drawing.Point(0, 0)
$header.Size = New-Object System.Drawing.Size(540, 78)
$header.BackColor = [System.Drawing.Color]::White
$form.Controls.Add($header)

$title = New-Object System.Windows.Forms.Label
$title.Location = New-Object System.Drawing.Point(24, 16)
$title.Size = New-Object System.Drawing.Size(490, 27)
$title.Text = 'Atualizador do Sistema'
$title.ForeColor = [System.Drawing.ColorTranslator]::FromHtml('#1238A8')
$title.Font = New-Object System.Drawing.Font('Segoe UI Semibold', 15)
$header.Controls.Add($title)

$subtitle = New-Object System.Windows.Forms.Label
$subtitle.Location = New-Object System.Drawing.Point(25, 47)
$subtitle.Size = New-Object System.Drawing.Size(480, 20)
$subtitle.Text = 'Dra. Cinthia Leone - Estética Dental'
$subtitle.ForeColor = [System.Drawing.ColorTranslator]::FromHtml('#6B7280')
$header.Controls.Add($subtitle)

$statusTitle = New-Object System.Windows.Forms.Label
$statusTitle.Location = New-Object System.Drawing.Point(25, 98)
$statusTitle.Size = New-Object System.Drawing.Size(490, 22)
$statusTitle.Text = 'Preparando a verificação...'
$statusTitle.ForeColor = [System.Drawing.ColorTranslator]::FromHtml('#1F2937')
$statusTitle.Font = New-Object System.Drawing.Font('Segoe UI Semibold', 10)
$form.Controls.Add($statusTitle)

$statusDetail = New-Object System.Windows.Forms.Label
$statusDetail.Location = New-Object System.Drawing.Point(25, 124)
$statusDetail.Size = New-Object System.Drawing.Size(490, 40)
$statusDetail.Text = 'O atualizador verificará a branch main do projeto.'
$statusDetail.ForeColor = [System.Drawing.ColorTranslator]::FromHtml('#6B7280')
$form.Controls.Add($statusDetail)

$progress = New-Object System.Windows.Forms.ProgressBar
$progress.Location = New-Object System.Drawing.Point(25, 174)
$progress.Size = New-Object System.Drawing.Size(490, 12)
$progress.Style = 'Marquee'
$progress.MarqueeAnimationSpeed = 22
$form.Controls.Add($progress)

$closeButton = New-Object System.Windows.Forms.Button
$closeButton.Location = New-Object System.Drawing.Point(400, 216)
$closeButton.Size = New-Object System.Drawing.Size(115, 36)
$closeButton.Text = 'Fechar'
$closeButton.FlatStyle = 'Flat'
$closeButton.FlatAppearance.BorderColor = [System.Drawing.ColorTranslator]::FromHtml('#D8D1C7')
$closeButton.BackColor = [System.Drawing.Color]::White
$closeButton.ForeColor = [System.Drawing.ColorTranslator]::FromHtml('#1F2937')
$closeButton.Enabled = $false
$form.Controls.Add($closeButton)

$projectLabel = New-Object System.Windows.Forms.Label
$projectLabel.Location = New-Object System.Drawing.Point(25, 225)
$projectLabel.Size = New-Object System.Drawing.Size(355, 22)
$projectLabel.Text = $ProjectPath
$projectLabel.ForeColor = [System.Drawing.ColorTranslator]::FromHtml('#8A8177')
$form.Controls.Add($projectLabel)

function Set-UpdateState {
    param(
        [string]$Title,
        [string]$Detail,
        [ValidateSet('Working', 'Success', 'Info', 'Error')][string]$Type = 'Working'
    )

    $statusTitle.Text = $Title
    $statusDetail.Text = $Detail

    switch ($Type) {
        'Success' {
            $statusTitle.ForeColor = [System.Drawing.ColorTranslator]::FromHtml('#16803A')
            $progress.Style = 'Continuous'
            $progress.Value = 100
        }
        'Info' {
            $statusTitle.ForeColor = [System.Drawing.ColorTranslator]::FromHtml('#1238A8')
            $progress.Style = 'Continuous'
            $progress.Value = 100
        }
        'Error' {
            $statusTitle.ForeColor = [System.Drawing.ColorTranslator]::FromHtml('#B42318')
            $progress.Style = 'Continuous'
            $progress.Value = 0
        }
        default {
            $statusTitle.ForeColor = [System.Drawing.ColorTranslator]::FromHtml('#1F2937')
            $progress.Style = 'Marquee'
            $progress.MarqueeAnimationSpeed = 22
        }
    }

    [System.Windows.Forms.Application]::DoEvents()
}

function Finish-Update {
    $script:Running = $false
    $closeButton.Enabled = $true
    $closeButton.Focus()
}

function Start-SystemUpdate {
    $script:Running = $true
    $closeButton.Enabled = $false
    Write-UpdateLog 'Início da verificação.'

    try {
        if (-not (Test-Path (Join-Path $ProjectPath '.git'))) {
            throw "Não encontrei um repositório Git em $ProjectPath."
        }

        $gitCommand = Get-Command 'git.exe' -ErrorAction SilentlyContinue
        if (-not $gitCommand) {
            throw 'O Git não está instalado ou não foi encontrado no PATH do Windows.'
        }

        Set-UpdateState 'Verificando o projeto...' 'Conferindo a branch e possíveis alterações locais.'

        $currentBranch = Invoke-Program $gitCommand.Source @('-C', $ProjectPath, 'branch', '--show-current')
        if ($currentBranch.Trim() -ne $BranchName) {
            throw "O projeto está na branch '$currentBranch'. Para atualizar, ele precisa estar na branch '$BranchName'."
        }

        $localChanges = Invoke-Program $gitCommand.Source @('-C', $ProjectPath, 'status', '--porcelain')
        if ($localChanges) {
            throw 'Existem arquivos alterados dentro do projeto. A atualização foi interrompida para não apagar nenhuma informação.'
        }

        Set-UpdateState 'Procurando atualizações...' 'Consultando a versão mais recente da branch main.'
        Invoke-Program $gitCommand.Source @('-C', $ProjectPath, 'fetch', $RemoteName, $BranchName, '--quiet') | Out-Null

        $localCommit = Invoke-Program $gitCommand.Source @('-C', $ProjectPath, 'rev-parse', 'HEAD')
        $remoteCommit = Invoke-Program $gitCommand.Source @('-C', $ProjectPath, 'rev-parse', "$RemoteName/$BranchName")

        if ($localCommit.Trim() -eq $remoteCommit.Trim()) {
            Set-UpdateState 'Não há atualizações disponíveis.' 'O sistema já está usando a versão mais recente.' 'Info'
            Write-UpdateLog 'Nenhuma atualização disponível.'
            [System.Windows.Forms.MessageBox]::Show(
                'O sistema já está atualizado.',
                'Dra. Cinthia Leone',
                [System.Windows.Forms.MessageBoxButtons]::OK,
                [System.Windows.Forms.MessageBoxIcon]::Information
            ) | Out-Null
            Finish-Update
            return
        }

        $dependencyFiles = Invoke-Program $gitCommand.Source @(
            '-C', $ProjectPath, 'diff', '--name-only', 'HEAD', "$RemoteName/$BranchName", '--',
            'package.json', 'package-lock.json', 'npm-shrinkwrap.json'
        )

        $npmCommand = $null
        if ($dependencyFiles) {
            $npmCommand = Get-Command 'npm.cmd' -ErrorAction SilentlyContinue
            if (-not $npmCommand) {
                throw 'A atualização possui novas dependências, mas o npm não foi encontrado. Instale o Node.js antes de continuar.'
            }
        }

        Set-UpdateState 'Baixando a atualização...' 'Aplicando a nova versão com segurança. Não feche esta janela.'
        Invoke-Program $gitCommand.Source @('-C', $ProjectPath, 'pull', '--ff-only', $RemoteName, $BranchName) | Out-Null

        if ($dependencyFiles) {
            Set-UpdateState 'Atualizando componentes...' 'Instalando as dependências necessárias do sistema.'

            if (Test-Path (Join-Path $ProjectPath 'package-lock.json')) {
                Invoke-Program $npmCommand.Source @('ci', '--no-audit', '--no-fund', '--prefix', $ProjectPath) | Out-Null
            }
            else {
                Invoke-Program $npmCommand.Source @('install', '--no-audit', '--no-fund', '--prefix', $ProjectPath) | Out-Null
            }
        }

        Set-UpdateState 'Sistema atualizado com sucesso!' 'A nova versão foi instalada. Agora você pode abrir o sistema normalmente.' 'Success'
        Write-UpdateLog "Atualização concluída: $localCommit -> $remoteCommit"

        [System.Windows.Forms.MessageBox]::Show(
            'Sistema atualizado com sucesso!',
            'Dra. Cinthia Leone',
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Information
        ) | Out-Null
    }
    catch {
        $errorMessage = $_.Exception.Message
        Write-UpdateLog "ERRO: $errorMessage"
        Set-UpdateState 'Não foi possível atualizar.' $errorMessage 'Error'

        [System.Windows.Forms.MessageBox]::Show(
            "$errorMessage`r`n`r`nNenhum arquivo local foi apagado.",
            'Falha na atualização',
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Error
        ) | Out-Null
    }
    finally {
        Finish-Update
    }
}

$closeButton.Add_Click({
    if (-not $script:Running) {
        $form.Close()
    }
})

$form.Add_FormClosing({
    param($sender, $eventArgs)

    if ($script:Running) {
        $eventArgs.Cancel = $true
    }
})

$form.Add_Shown({
    $confirmation = [System.Windows.Forms.MessageBox]::Show(
        "Antes de atualizar, feche o sistema da Dra. Cinthia e o servidor local.`r`n`r`nDeseja verificar as atualizações agora?",
        'Atualizador do Sistema',
        [System.Windows.Forms.MessageBoxButtons]::OKCancel,
        [System.Windows.Forms.MessageBoxIcon]::Information
    )

    if ($confirmation -eq [System.Windows.Forms.DialogResult]::OK) {
        Start-SystemUpdate
    }
    else {
        Set-UpdateState 'Atualização cancelada.' 'Nenhuma alteração foi realizada.' 'Info'
        Finish-Update
    }
})

[System.Windows.Forms.Application]::Run($form)

