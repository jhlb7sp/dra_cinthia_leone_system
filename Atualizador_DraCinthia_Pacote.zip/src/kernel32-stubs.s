.text
.globl CreateProcessW
.globl WaitForSingleObject
.globl CloseHandle
.globl GetExitCodeProcess
.globl ExitProcess
CreateProcessW:
WaitForSingleObject:
CloseHandle:
GetExitCodeProcess:
ExitProcess:
    ret

