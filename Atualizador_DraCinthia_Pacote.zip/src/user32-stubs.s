.text
.globl MessageBoxW
MessageBoxW:
    ret

