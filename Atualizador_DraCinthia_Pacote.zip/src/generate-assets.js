const fs = require('fs');
const path = require('path');

const sourceDirectory = __dirname;
const mode = process.argv[2] || 'generate';

function align(value, alignment) {
  return Math.ceil(value / alignment) * alignment;
}

function createCommandInclude() {
  const scriptPath = path.join(sourceDirectory, 'AtualizarSistema.ps1');
  const script = fs.readFileSync(scriptPath, 'utf8');
  const encodedScript = Buffer.from(script, 'utf16le').toString('base64');
  const command = `powershell.exe -NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -EncodedCommand ${encodedScript}`;

  if (command.length >= 32000) {
    throw new Error(`A linha de comando ficou muito grande: ${command.length} caracteres.`);
  }

  const values = [];
  for (let index = 0; index < command.length; index += 1) {
    values.push(command.charCodeAt(index));
  }
  values.push(0);

  const lines = [];
  for (let index = 0; index < values.length; index += 16) {
    lines.push(`    ${values.slice(index, index + 16).map((value) => `0x${value.toString(16).padStart(4, '0')}`).join(', ')}`);
  }

  const include = `static WCHAR commandLine[] = {\n${lines.join(',\n')}\n};\n`;
  fs.writeFileSync(path.join(sourceDirectory, 'launcher-command.inc'), include);
  fs.writeFileSync(
    path.join(sourceDirectory, 'command-info.json'),
    JSON.stringify({ commandLength: command.length, encodedLength: encodedScript.length }, null, 2),
  );
}

function createIconResource() {
  const iconPath = path.join(sourceDirectory, '..', 'iconCL.ico');
  const icon = fs.readFileSync(iconPath);

  if (icon.readUInt16LE(0) !== 0 || icon.readUInt16LE(2) !== 1) {
    throw new Error('Arquivo ICO inválido.');
  }

  const iconCount = icon.readUInt16LE(4);
  const icons = [];

  for (let index = 0; index < iconCount; index += 1) {
    const entryOffset = 6 + index * 16;
    const size = icon.readUInt32LE(entryOffset + 8);
    const dataOffset = icon.readUInt32LE(entryOffset + 12);

    icons.push({
      id: index + 1,
      width: icon[entryOffset],
      height: icon[entryOffset + 1],
      colorCount: icon[entryOffset + 2],
      reserved: icon[entryOffset + 3],
      planes: icon.readUInt16LE(entryOffset + 4),
      bitCount: icon.readUInt16LE(entryOffset + 6),
      data: icon.subarray(dataOffset, dataOffset + size),
    });
  }

  let cursor = 0;
  const allocate = (size, alignment = 4) => {
    cursor = align(cursor, alignment);
    const offset = cursor;
    cursor += size;
    return offset;
  };

  const rootDirectory = allocate(16 + 2 * 8);
  const iconTypeDirectory = allocate(16 + iconCount * 8);
  const groupTypeDirectory = allocate(16 + 8);
  const iconLanguageDirectories = icons.map(() => allocate(16 + 8));
  const groupLanguageDirectory = allocate(16 + 8);
  const iconDataEntries = icons.map(() => allocate(16));
  const groupDataEntry = allocate(16);

  const groupData = Buffer.alloc(6 + iconCount * 14);
  groupData.writeUInt16LE(0, 0);
  groupData.writeUInt16LE(1, 2);
  groupData.writeUInt16LE(iconCount, 4);

  icons.forEach((item, index) => {
    const offset = 6 + index * 14;
    groupData[offset] = item.width;
    groupData[offset + 1] = item.height;
    groupData[offset + 2] = item.colorCount;
    groupData[offset + 3] = item.reserved;
    groupData.writeUInt16LE(item.planes, offset + 4);
    groupData.writeUInt16LE(item.bitCount, offset + 6);
    groupData.writeUInt32LE(item.data.length, offset + 8);
    groupData.writeUInt16LE(item.id, offset + 12);
  });

  const groupDataOffset = allocate(groupData.length);
  const iconDataOffsets = icons.map((item) => allocate(item.data.length));
  const resource = Buffer.alloc(align(cursor, 4));

  function writeDirectory(offset, entries) {
    resource.writeUInt32LE(0, offset);
    resource.writeUInt32LE(0, offset + 4);
    resource.writeUInt16LE(0, offset + 8);
    resource.writeUInt16LE(0, offset + 10);
    resource.writeUInt16LE(0, offset + 12);
    resource.writeUInt16LE(entries.length, offset + 14);

    entries.forEach((entry, index) => {
      const entryOffset = offset + 16 + index * 8;
      resource.writeUInt32LE(entry.id, entryOffset);
      resource.writeUInt32LE(entry.directory ? (entry.offset | 0x80000000) >>> 0 : entry.offset, entryOffset + 4);
    });
  }

  writeDirectory(rootDirectory, [
    { id: 3, offset: iconTypeDirectory, directory: true },
    { id: 14, offset: groupTypeDirectory, directory: true },
  ]);

  writeDirectory(
    iconTypeDirectory,
    icons.map((item, index) => ({ id: item.id, offset: iconLanguageDirectories[index], directory: true })),
  );
  writeDirectory(groupTypeDirectory, [{ id: 1, offset: groupLanguageDirectory, directory: true }]);

  icons.forEach((item, index) => {
    writeDirectory(iconLanguageDirectories[index], [{ id: 1033, offset: iconDataEntries[index], directory: false }]);
  });
  writeDirectory(groupLanguageDirectory, [{ id: 1033, offset: groupDataEntry, directory: false }]);

  const patches = [];
  icons.forEach((item, index) => {
    const dataEntry = iconDataEntries[index];
    resource.writeUInt32LE(0, dataEntry);
    resource.writeUInt32LE(item.data.length, dataEntry + 4);
    resource.writeUInt32LE(0, dataEntry + 8);
    resource.writeUInt32LE(0, dataEntry + 12);
    patches.push({ position: dataEntry, dataOffset: iconDataOffsets[index] });
    item.data.copy(resource, iconDataOffsets[index]);
  });

  resource.writeUInt32LE(0, groupDataEntry);
  resource.writeUInt32LE(groupData.length, groupDataEntry + 4);
  resource.writeUInt32LE(0, groupDataEntry + 8);
  resource.writeUInt32LE(0, groupDataEntry + 12);
  patches.push({ position: groupDataEntry, dataOffset: groupDataOffset });
  groupData.copy(resource, groupDataOffset);

  fs.writeFileSync(path.join(sourceDirectory, 'icon-resource.bin'), resource);
  fs.writeFileSync(
    path.join(sourceDirectory, 'resource-manifest.json'),
    JSON.stringify({ iconCount, resourceSize: resource.length, patches }, null, 2),
  );
}

function patchExecutable() {
  const executablePath = path.join(sourceDirectory, '..', 'Atualizar_Sistema_DraCinthia.exe');
  const executable = fs.readFileSync(executablePath);
  const manifest = JSON.parse(fs.readFileSync(path.join(sourceDirectory, 'resource-manifest.json'), 'utf8'));
  const peOffset = executable.readUInt32LE(0x3c);

  if (executable.toString('ascii', peOffset, peOffset + 4) !== 'PE\u0000\u0000') {
    throw new Error('Executável PE inválido.');
  }

  const sectionCount = executable.readUInt16LE(peOffset + 6);
  const optionalHeaderSize = executable.readUInt16LE(peOffset + 20);
  const sectionTableOffset = peOffset + 24 + optionalHeaderSize;
  let resourceSection = null;

  for (let index = 0; index < sectionCount; index += 1) {
    const sectionOffset = sectionTableOffset + index * 40;
    const name = executable.toString('ascii', sectionOffset, sectionOffset + 8).replace(/\u0000+$/, '');

    if (name === '.rsrc') {
      resourceSection = {
        virtualAddress: executable.readUInt32LE(sectionOffset + 12),
        rawPointer: executable.readUInt32LE(sectionOffset + 20),
      };
      break;
    }
  }

  if (!resourceSection) {
    throw new Error('Seção de recursos não encontrada.');
  }

  manifest.patches.forEach((patch) => {
    executable.writeUInt32LE(
      resourceSection.virtualAddress + patch.dataOffset,
      resourceSection.rawPointer + patch.position,
    );
  });

  fs.writeFileSync(executablePath, executable);
}

if (mode === 'generate') {
  createCommandInclude();
  createIconResource();
}
else if (mode === 'patch') {
  patchExecutable();
}
else {
  throw new Error(`Modo desconhecido: ${mode}`);
}

