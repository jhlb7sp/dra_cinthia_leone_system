.section .rsrc,"a"
.globl updater_resources
updater_resources:
    .incbin "icon-resource.bin"

